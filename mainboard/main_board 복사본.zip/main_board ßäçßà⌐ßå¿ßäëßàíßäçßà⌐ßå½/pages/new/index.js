import WriterPage from "../../src/components/units/board/write/Writer.container";

export default function WriterMainPage() {
  return <WriterPage isEdit={false}></WriterPage>;
}
